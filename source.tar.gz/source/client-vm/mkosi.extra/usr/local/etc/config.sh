#!/bin/bash
SERVER_IP=1.2.3.4
